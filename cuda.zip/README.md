to compile: ```make```
to run:
```
./main --device 0,1 --threads 1 --output output.txt
```
