#include <chrono>
#include <optional>

#include "cpu.h"
#include "../cubiomes/finders.h"
#include "../cubiomes/generator.h"
#include "../cubiomes/biomenoise.h"

struct Noises
{
    BiomeNoise *t;
    BiomeNoise *h;
    BiomeNoise *c;
    BiomeNoise *e;
    BiomeNoise *w;
};

static double sample(BiomeNoise *bn, int a, int b, int x, int z)
{
    double v = 0;
    if (a)
    {
        OctaveNoise *on = &bn->climate[bn->nptype].octA;
        for (int i = 0; i < on->octcnt; i++)
        {
            if (a & (1 << i))
            {
                PerlinNoise *pn = on->octaves + i;
                double l = pn->lacunarity;
                v += samplePerlin(pn, x * l, 0, z * l, 0, 0) * pn->amplitude;
            }
        }
    }
    if (b)
    {
        OctaveNoise *on = &bn->climate[bn->nptype].octB;
        for (int i = 0; i < on->octcnt; i++)
        {
            if (b & (1 << i))
            {
                PerlinNoise *pn = on->octaves + i;
                double l = pn->lacunarity * (337.0 / 331.0);
                v += samplePerlin(pn, x * l, 0, z * l, 0, 0) * pn->amplitude;
            }
        }
    }
    return v * bn->climate[bn->nptype].amplitude;
}

static int eval_climates(int x, int z, void *data)
{
    Noises *n = (Noises *)data;
    if (sample(n->w, 0b111, 0b111, x, z) < 0.9333)
    {
        return 0;
    }
    if (sample(n->h, 0b1111, 0b1111, x, z) > -0.1)
    {
        return 0;
    }
    if (sample(n->t, 0b1111, 0b1111, x, z) > 0.2)
    {
        return 0;
    }
    if (sample(n->t, 0b1111, 0b1111, x, z) < -0.45)
    {
        return 0;
    }
    if (sample(n->t, 0b1111, 0b1111, x, z) < -0.15 && sample(n->h, 0b1111, 0b1111, x, z) > -0.35)
    {
        return 0;
    }
    if (sample(n->e, 0b1111, 0b1111, x, z) > -0.375)
    {
        return 0;
    }
    if (sample(n->e, 0b1111, 0b1111, x, z) < -0.78)
    {
        return 0;
    }
    if (sample(n->c, 0b1111, 0b1111, x, z) < 0.3)
    {
        return 0;
    }
    return 1;
}

static int flood(int x, int z, void *data, int (*eval)(int, int, void *), int *out_x, int *out_z)
{
    int origin_x = x / 8;
    int origin_z = z / 8;
    if (!eval(origin_x * 8, origin_z * 8, data))
    {
        return 0;
    }
    uint8_t visited[128][128] = {0};
    int queue_x[16384];
    int queue_z[16384];
    int head = 0;
    int tail = 0;
    int area = 0;
    int64_t sum_x = 0;
    int64_t sum_z = 0;
    visited[64][64] = 1;
    queue_x[tail] = 64;
    queue_z[tail] = 64;
    tail++;
    while (head < tail)
    {
        int lx = queue_x[head];
        int lz = queue_z[head];
        int target_x = lx + origin_x - 64;
        int target_z = lz + origin_z - 64;
        head++;
        area++;
        sum_x += (int64_t)target_x;
        sum_z += (int64_t)target_z;
        int dx[4] = {1, -1, 0, 0};
        int dz[4] = {0, 0, 1, -1};
        for (int i = 0; i < 4; i++)
        {
            int nx = lx + dx[i];
            int nz = lz + dz[i];
            if (nx >= 0 && nx < 128 && nz >= 0 && nz < 128 && !visited[nz][nx])
            {
                visited[nz][nx] = 1;
                int n_target_x = nx + origin_x - 64;
                int n_target_z = nz + origin_z - 64;
                int result = eval(n_target_x * 8, n_target_z * 8, data);
                if (result == 1)
                {
                    queue_x[tail] = nx;
                    queue_z[tail] = nz;
                    tail++;
                }
                else if (result == -1)
                {
                    return 0;
                }
            }
        }
    }
    if (area && out_x && out_z)
    {
        *out_x = (int)((sum_x * 8) / area);
        *out_z = (int)((sum_z * 8) / area);
    }
    return area * 1024;
}

std::optional<CpuOutput> process(Generator *g, Noises *n, const GpuOutput &input)
{
    setClimateParaSeed(n->c, input.seed, 1, NP_CONTINENTALNESS, 8);
    setClimateParaSeed(n->e, input.seed, 1, NP_EROSION, 8);
    setClimateParaSeed(n->w, input.seed, 1, NP_WEIRDNESS, 6);
    setClimateParaSeed(n->h, input.seed, 1, NP_HUMIDITY, 4);
    setClimateParaSeed(n->t, input.seed, 1, NP_TEMPERATURE, 4);
    if (!eval_climates(input.x / 4, input.z / 4, n))
    {
        return {};
    }
    int32_t area = flood(input.x / 4, input.z / 4, n, eval_climates, NULL, NULL);
    if (area < 550000)
    {
        return {};
    }
    return (CpuOutput){input.seed, input.x, input.z, area};
}

CpuThread::CpuThread(int id, GpuOutputs &inputs, CpuOutputs &outputs) : Thread(), id(id), inputs(inputs), outputs(outputs)
{
    start();
}

void CpuThread::run()
{
    Generator g;
    setupGenerator(&g, MC_NEWEST, 0);
    BiomeNoise t = g.bn;
    BiomeNoise h = g.bn;
    BiomeNoise c = g.bn;
    BiomeNoise e = g.bn;
    BiomeNoise w = g.bn;
    Noises n;
    n.t = &t;
    n.h = &h;
    n.c = &c;
    n.e = &e;
    n.w = &w;
    while (!should_stop())
    {
        GpuOutput input;
        {
            std::unique_lock lock(inputs.mutex);
            if (inputs.queue.empty())
            {
                lock.unlock();
                std::this_thread::sleep_for(std::chrono::seconds(1));
                continue;
            }
            input = inputs.queue.front();
            inputs.queue.pop();
        }
        const auto output = process(&g, &n, input);
        if (!output)
        {
            continue;
        }
        {
            std::lock_guard lock(outputs.mutex);
            outputs.queue.push(output.value());
        }
    }
}
