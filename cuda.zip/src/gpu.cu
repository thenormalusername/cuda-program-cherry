#include <array>
#include <bit>
#include <chrono>
#include <cinttypes>
#include <cstdint>
#include <cstdio>
#include <mutex>
#include <random>

#include "Random.h"
#include "gpu.h"

#define TRY_CUDA(expr) try_cuda(expr, __FILE__, __LINE__)

#define PANIC(...)                         \
    {                                      \
        std::fprintf(stderr, __VA_ARGS__); \
        std::abort();                      \
    }

void try_cuda(cudaError_t error, const char *file, uint64_t line)
{
    if (error == cudaSuccess)
    {
        return;
    }
    PANIC("CUDA error at %s:%" PRIu64 ": %s\n", file, line, cudaGetErrorString(error));
}

constexpr XrsrForkHash hash_weirdness{0xefc8ef4d36102b34, 0x1beeeb324a0f24ea};
constexpr XrsrForkHash hash_weirdness_large{0xefc8ef4d36102b34, 0x1beeeb324a0f24ea};
constexpr XrsrForkHash hash_octave[]{
    {0xb198de63a8012672, 0x7b84cad43ef7b5a8},
    {0x0fd787bfbc403ec3, 0x74a4a31ca21b48b8},
    {0x36d326eed40efeb2, 0x5be9ce18223c636a},
    {0x082fe255f8be6631, 0x4e96119e22dedc81},
    {0x0ef68ec68504005e, 0x48b6bf93a2789640},
    {0xf11268128982754f, 0x257a1d670430b0aa},
    {0xe51c98ce7d1de664, 0x5f9478a733040c45},
    {0x6d7b49e7e429850a, 0x2e3063c622a24777},
    {0xbd90d5377ba1b762, 0xc07317d419a7548d},
    {0x53d39c6752dac858, 0xbcd1c5a80ab65b3e},
    {0xb4a24d7a84e7677b, 0x023ff9668e89b5c4},
    {0xdffa22b534c5f608, 0xb9b67517d3665ca9},
    {0xd50708086cef4d7c, 0x6e1651ecc7f43309},
};

struct ImprovedNoise
{
    uint8_t p[256];
    float xo;
    float yo;
    float zo;
};

struct Octave
{
    ImprovedNoise noise;
    double input_factor;
    double value_factor;
};

template <size_t N>
struct NoiseParameters
{
    int32_t first_octave;
    std::array<double, N> amplitudes;
};

template <size_t N>
constexpr NoiseParameters<N> make_noise_parameters(int32_t first_octave, const double (&amplitudes)[N])
{
    std::array<double, N> amp{};
    std::copy(std::begin(amplitudes), std::end(amplitudes), amp.begin());
    return {first_octave, amp};
}

constexpr auto weirdness_parameters = make_noise_parameters(-7, {1.0, 2.0, 1.0, 0.0, 0.0, 0.0});
constexpr auto weirdness_large_parameters = make_noise_parameters(-7, {1.0, 2.0, 1.0, 0.0, 0.0, 0.0});

struct OctaveConfig
{
    XrsrForkHash fork_hash;
    double input_factor;
    double value_factor;
};

template <size_t N>
struct NormalNoiseConfig
{
    XrsrForkHash fork_hash;
    std::array<OctaveConfig, N> octaves_a;
    std::array<OctaveConfig, N> octaves_b;
};

template <size_t N>
constexpr NormalNoiseConfig<N> make_normal_noise_config(const NoiseParameters<N> &noise_parameters, const XrsrForkHash &fork_hash)
{
    NormalNoiseConfig<N> res{fork_hash};
    const auto first_octave = noise_parameters.first_octave;
    const auto &amplitudes = noise_parameters.amplitudes;
    double root_value_factor = 0.16666666666666666 / (0.1 * (1.0 + 1.0 / (amplitudes.size() - 3)));
    double input_factor = 1.0 / (1 << -first_octave);
    double value_factor = (1 << (amplitudes.size() - 1)) / ((1 << amplitudes.size()) - 1.0) * root_value_factor;
    for (size_t i = 0; i < amplitudes.size(); i++)
    {
        res.octaves_a[i] = {hash_octave[first_octave + 12 + i], input_factor, value_factor * amplitudes[i]};
        res.octaves_b[i] = {hash_octave[first_octave + 12 + i], input_factor * 1.0181268882175227, value_factor * amplitudes[i]};
        input_factor *= 2.0;
        value_factor *= 0.5;
    }
    return res;
}

constexpr auto weirdness_config = make_normal_noise_config(weirdness_parameters, hash_weirdness);
constexpr auto weirdness_large_config = make_normal_noise_config(weirdness_large_parameters, hash_weirdness_large);
constexpr auto chosen_weirdness_config = large_biomes ? weirdness_large_config : weirdness_config;
__device__ constexpr auto device_chosen_weirdness_config = chosen_weirdness_config;

struct GradDotTable
{
    float x[16];
    float y[16];
    float z[16];
};

__device__ GradDotTable device_grad_dot_table;

void init_grad_dot_table()
{
    GradDotTable table;
    table.x[0] = 1;
    table.y[0] = 1;
    table.z[0] = 0;
    table.x[1] = -1;
    table.y[1] = 1;
    table.z[1] = 0;
    table.x[2] = 1;
    table.y[2] = -1;
    table.z[2] = 0;
    table.x[3] = -1;
    table.y[3] = -1;
    table.z[3] = 0;
    table.x[4] = 1;
    table.y[4] = 0;
    table.z[4] = 1;
    table.x[5] = -1;
    table.y[5] = 0;
    table.z[5] = 1;
    table.x[6] = 1;
    table.y[6] = 0;
    table.z[6] = -1;
    table.x[7] = -1;
    table.y[7] = 0;
    table.z[7] = -1;
    table.x[8] = 0;
    table.y[8] = 1;
    table.z[8] = 1;
    table.x[9] = 0;
    table.y[9] = -1;
    table.z[9] = 1;
    table.x[10] = 0;
    table.y[10] = 1;
    table.z[10] = -1;
    table.x[11] = 0;
    table.y[11] = -1;
    table.z[11] = -1;
    table.x[12] = 1;
    table.y[12] = 1;
    table.z[12] = 0;
    table.x[13] = 0;
    table.y[13] = -1;
    table.z[13] = 1;
    table.x[14] = -1;
    table.y[14] = 1;
    table.z[14] = 0;
    table.x[15] = 0;
    table.y[15] = -1;
    table.z[15] = -1;
    void *device_grad_dot_table_addr;
    TRY_CUDA(cudaGetSymbolAddress(&device_grad_dot_table_addr, device_grad_dot_table));
    TRY_CUDA(cudaMemcpy(device_grad_dot_table_addr, &table, sizeof(GradDotTable), cudaMemcpyHostToDevice));
}

__device__ float gradDot(const GradDotTable &table, uint8_t p, float x, float y, float z)
{
    return x * table.x[p & 0xF] + y * table.y[p & 0xF] + z * table.z[p & 0xF];
}

__device__ float smoothstep(float value)
{
    return value * value * value * (value * (value * 6.0f - 15.0f) + 10.0f);
}

__device__ float lerp1(float fx, float v0, float v1)
{
    return v0 + fx * (v1 - v0);
}

__device__ float lerp2(float fx, float fy, float v00, float v10, float v01, float v11)
{
    return lerp1(fy, lerp1(fx, v00, v10), lerp1(fx, v01, v11));
}

__device__ float lerp3(float fx, float fy, float fz, float v000, float v100, float v010, float v110, float v001, float v101, float v011, float v111)
{
    return lerp1(fz, lerp2(fx, fy, v000, v100, v010, v110), lerp2(fx, fy, v001, v101, v011, v111));
}

__device__ float sample_noise(const GradDotTable &table, const ImprovedNoise &noise, float x, float y, float z)
{
    x += noise.xo;
    y += noise.yo;
    z += noise.zo;
    float floor_x = std::floor(x);
    float floor_y = std::floor(y);
    float floor_z = std::floor(z);
    float frac_x = x - floor_x;
    float frac_y = y - floor_y;
    float frac_z = z - floor_z;
    int32_t int_x = floor_x;
    int32_t int_y = floor_y;
    int32_t int_z = floor_z;
    uint8_t p0 = noise.p[(int_x) & 0xFF];
    uint8_t p1 = noise.p[(int_x + 1) & 0xFF];
    uint8_t p00 = noise.p[(p0 + int_y) & 0xFF];
    uint8_t p01 = noise.p[(p0 + int_y + 1) & 0xFF];
    uint8_t p10 = noise.p[(p1 + int_y) & 0xFF];
    uint8_t p11 = noise.p[(p1 + int_y + 1) & 0xFF];
    float n000 = gradDot(table, noise.p[(p00 + int_z) & 0xFF], frac_x, frac_y, frac_z);
    float n100 = gradDot(table, noise.p[(p10 + int_z) & 0xFF], frac_x - 1.0f, frac_y, frac_z);
    float n010 = gradDot(table, noise.p[(p01 + int_z) & 0xFF], frac_x, frac_y - 1.0f, frac_z);
    float n110 = gradDot(table, noise.p[(p11 + int_z) & 0xFF], frac_x - 1.0f, frac_y - 1.0f, frac_z);
    float n001 = gradDot(table, noise.p[(p00 + int_z + 1) & 0xFF], frac_x, frac_y, frac_z - 1.0f);
    float n101 = gradDot(table, noise.p[(p10 + int_z + 1) & 0xFF], frac_x - 1.0f, frac_y, frac_z - 1.0f);
    float n011 = gradDot(table, noise.p[(p01 + int_z + 1) & 0xFF], frac_x, frac_y - 1.0f, frac_z - 1.0f);
    float n111 = gradDot(table, noise.p[(p11 + int_z + 1) & 0xFF], frac_x - 1.0f, frac_y - 1.0f, frac_z - 1.0f);
    float fx = smoothstep(frac_x);
    float fy = smoothstep(frac_y);
    float fz = smoothstep(frac_z);
    return lerp3(fx, fy, fz, n000, n100, n010, n110, n001, n101, n011, n111);
}

__device__ float wrap(float value)
{
    return value;
}

template <OctaveConfig config>
__device__ float sample_octave(const GradDotTable &table, const ImprovedNoise &noise, int32_t x, int32_t y, int32_t z)
{
    return sample_noise(table, noise, wrap(x * (float)config.input_factor), wrap(y * (float)config.input_factor), wrap(z * (float)config.input_factor)) * (float)config.value_factor;
}

__device__ void init_noise(ImprovedNoise &noise, XrsrRandom &&random)
{
    noise.xo = random.nextFloat() * 256.0f;
    noise.yo = random.nextFloat() * 256.0f;
    noise.zo = random.nextFloat() * 256.0f;
    for (uint32_t i = 0; i < 256; i++)
    {
        noise.p[i] = i;
    }
    for (uint32_t i = 0; i < 256; i++)
    {
        uint32_t j = random.nextInt(256 - i);
        uint8_t b = noise.p[i];
        noise.p[i] = noise.p[i + j];
        noise.p[i + j] = b;
    }
}

struct DeviceBuffer
{
    void *data;
    size_t size;
    DeviceBuffer(size_t size) : size(size)
    {
        TRY_CUDA(cudaMalloc(&data, size));
    }
    ~DeviceBuffer()
    {
        TRY_CUDA(cudaFree(data));
    }
};

template <typename T>
struct OutputBuffer
{
    T *data;
    uint32_t &len;
    uint32_t max_len;
    OutputBuffer(T *data, uint32_t &len, uint32_t max_len) : data(data), len(len), max_len(max_len) {}
    OutputBuffer(const DeviceBuffer &buffer, uint32_t &len) : data((T *)buffer.data), len(len), max_len(buffer.size / sizeof(T)) {}
    OutputBuffer(const OutputBuffer<T> &other) : data(other.data), len(other.len), max_len(other.max_len) {}
};

template <typename T>
struct InputBuffer
{
    const T *data;
    const uint32_t &len;
    InputBuffer(const T *data, const uint32_t &len) : data(data), len(len) {}
    InputBuffer(const OutputBuffer<T> &buffer) : data(buffer.data), len(buffer.len) {}
    InputBuffer(const InputBuffer<T> &other) : data(other.data), len(other.len) {}
};

namespace KernelSeed1
{
    constexpr uint32_t threads_per_run = UINT64_C(1) << 16;
    constexpr uint32_t threads_per_block = 32;
    struct Result
    {
        ImprovedNoise weirdness_0A;
        ImprovedNoise weirdness_0B;
        ImprovedNoise weirdness_1A;
        ImprovedNoise weirdness_1B;
        ImprovedNoise weirdness_2A;
        ImprovedNoise weirdness_2B;
    };
    template <size_t Octaves>
    struct ResultSampler
    {
        ImprovedNoise octaves[Octaves];
        __device__ float sample(const GradDotTable &table, int32_t x, int32_t y, int32_t z) const
        {
            float val = 0;
            if constexpr (Octaves >= 1)
            {
                val += sample_octave<chosen_weirdness_config.octaves_a[0]>(table, octaves[0], x, y, z);
            }
            if constexpr (Octaves >= 2)
            {
                val += sample_octave<chosen_weirdness_config.octaves_b[0]>(table, octaves[1], x, y, z);
            }
            if constexpr (Octaves >= 3)
            {
                val += sample_octave<chosen_weirdness_config.octaves_a[1]>(table, octaves[2], x, y, z);
            }
            if constexpr (Octaves >= 4)
            {
                val += sample_octave<chosen_weirdness_config.octaves_b[1]>(table, octaves[3], x, y, z);
            }
            if constexpr (Octaves >= 5)
            {
                val += sample_octave<chosen_weirdness_config.octaves_a[2]>(table, octaves[4], x, y, z);
            }
            if constexpr (Octaves >= 6)
            {
                val += sample_octave<chosen_weirdness_config.octaves_b[2]>(table, octaves[5], x, y, z);
            }
            return val;
        }
    };
    __device__ Result results[threads_per_run];
    __device__ void copy_noise(ImprovedNoise (&shared_noise)[threads_per_block], ImprovedNoise Result::*result_member)
    {
        for (uint32_t result_index = 0; result_index < threads_per_block; result_index++)
        {
            ImprovedNoise &src = shared_noise[result_index];
            ImprovedNoise &dst = results[blockIdx.x * blockDim.x + result_index].*result_member;
            for (uint32_t i = threadIdx.x; i < sizeof(ImprovedNoise) / sizeof(uint32_t); i += threads_per_block)
            {
                reinterpret_cast<uint32_t *>(&dst)[i] = reinterpret_cast<uint32_t *>(&src)[i];
            }
        }
    }
    __device__ void init_octave(const XrsrRandomFork &noise_fork, const XrsrForkHash &fork_hash, ImprovedNoise Result::*result_member)
    {
        __shared__ ImprovedNoise shared_noise[threads_per_block];
        init_noise(shared_noise[threadIdx.x], noise_fork.from(fork_hash));
        __syncthreads();
        copy_noise(shared_noise, result_member);
        __syncthreads();
    }
    __global__ __launch_bounds__(threads_per_block) void kernel(InputBuffer<uint64_t> input)
    {
        uint32_t index = blockIdx.x * blockDim.x + threadIdx.x;
        if (index / threads_per_block * threads_per_block >= input.len)
        {
            return;
        }
        uint64_t seed = input.data[index];
        const auto seed_fork = XrsrRandom(seed).fork();
        auto noise_random = seed_fork.from(device_chosen_weirdness_config.fork_hash);
        const auto noise_a_fork = noise_random.fork();
        init_octave(noise_a_fork, device_chosen_weirdness_config.octaves_a[0].fork_hash, &Result::weirdness_0A);
        init_octave(noise_a_fork, device_chosen_weirdness_config.octaves_a[1].fork_hash, &Result::weirdness_1A);
        const auto noise_b_fork = noise_random.fork();
        init_octave(noise_b_fork, device_chosen_weirdness_config.octaves_b[0].fork_hash, &Result::weirdness_0B);
        init_octave(noise_b_fork, device_chosen_weirdness_config.octaves_b[1].fork_hash, &Result::weirdness_1B);
    }
}

struct SeedPos
{
    uint32_t seed_index;
    int32_t x;
    int32_t z;
};

template <typename T>
__device__ T warp_reduce_add(T val)
{
#if __CUDA_ARCH__ >= 800
    return __reduce_add_sync(-1u, val);
#else
    val += __shfl_down_sync(-1u, val, 1);
    val += __shfl_down_sync(-1u, val, 2);
    val += __shfl_down_sync(-1u, val, 4);
    val += __shfl_down_sync(-1u, val, 8);
    val += __shfl_down_sync(-1u, val, 16);
    return val;
#endif
}

__device__ float warp_reduce_max(float val)
{
#if __CUDA_ARCH__ >= 800
    return __reduce_max_sync(0xFFFFFFFF, val);
#else
    float lane_val;
    lane_val = __shfl_down_sync(-1u, val, 1);
    val = fmaxf(lane_val, val);
    lane_val = __shfl_down_sync(-1u, val, 2);
    val = fmaxf(lane_val, val);
    lane_val = __shfl_down_sync(-1u, val, 4);
    val = fmaxf(lane_val, val);
    lane_val = __shfl_down_sync(-1u, val, 8);
    val = fmaxf(lane_val, val);
    lane_val = __shfl_down_sync(-1u, val, 16);
    val = fmaxf(lane_val, val);
    return val;
#endif
}

__device__ float warp_reduce_min(float val)
{
#if __CUDA_ARCH__ >= 800
    return __reduce_min_sync(0xFFFFFFFF, val);
#else
    float lane_val;
    lane_val = __shfl_down_sync(-1u, val, 1);
    val = fminf(lane_val, val);
    lane_val = __shfl_down_sync(-1u, val, 2);
    val = fminf(lane_val, val);
    lane_val = __shfl_down_sync(-1u, val, 4);
    val = fminf(lane_val, val);
    lane_val = __shfl_down_sync(-1u, val, 8);
    val = fminf(lane_val, val);
    lane_val = __shfl_down_sync(-1u, val, 16);
    val = fminf(lane_val, val);
    return val;
#endif
}

namespace KernelFilterYOffset
{
    constexpr uint32_t threads_per_block = 256;
    constexpr uint32_t threads_per_run = UINT64_C(1) << 18;
    __device__ XrsrRandomFork noise_yo_fork(XrsrRandomFork noise_fork)
    {
        XrsrRandom rng{noise_fork.lo, noise_fork.hi};
        rng.nextInternal();
        return {rng.lo, rng.hi};
    }
    constexpr XrsrForkHash octave_yo_fork_hash(XrsrForkHash hash)
    {
        XrsrRandom rng{hash.lo, hash.hi};
        rng.nextInternal();
        return {rng.lo, rng.hi};
    }
    template <OctaveConfig octave_config>
    __device__ float octave_yo_mod1(const XrsrRandomFork &noise_yo_fork)
    {
        constexpr auto fork_hash = octave_yo_fork_hash(octave_config.fork_hash);
        return ((uint32_t)noise_yo_fork.from(fork_hash).nextBits(32) & 0xFFFFFF) * 5.9604645E-8f;
    }
    __global__ __launch_bounds__(threads_per_block) void kernel(uint64_t start_seed, OutputBuffer<uint64_t> outputs)
    {
        uint32_t index = blockIdx.x * blockDim.x + threadIdx.x;
        uint64_t seed = start_seed + index;
        const auto seed_fork = XrsrRandom(seed).fork();
        auto noise_random = seed_fork.from(device_chosen_weirdness_config.fork_hash);
        auto noise_a_yo_fork = noise_yo_fork(noise_random.fork());
        float w_0A_yo = octave_yo_mod1<chosen_weirdness_config.octaves_a[0]>(noise_a_yo_fork);
        float w_1A_yo = octave_yo_mod1<chosen_weirdness_config.octaves_a[1]>(noise_a_yo_fork);
        auto noise_b_yo_fork = noise_yo_fork(noise_random.fork());
        float w_0B_yo = octave_yo_mod1<chosen_weirdness_config.octaves_b[0]>(noise_b_yo_fork);
        float w_1B_yo = octave_yo_mod1<chosen_weirdness_config.octaves_b[1]>(noise_b_yo_fork);
        float score = fabsf(w_0A_yo - 0.5f) + fabsf(w_1A_yo - 0.5f) + fabsf(w_0B_yo - 0.5f) + fabsf(w_1B_yo - 0.5f);
        if (score > 0.2f)
        {
            return;
        }
        uint32_t result_index = atomicAdd(&outputs.len, 1);
        if (result_index < outputs.max_len)
        {
            outputs.data[result_index] = seed;
        }
    }
    void run(uint64_t start_seed, OutputBuffer<uint64_t> outputs)
    {
        kernel<<<threads_per_run / threads_per_block, threads_per_block>>>(start_seed, outputs);
        TRY_CUDA(cudaGetLastError());
    }
}

namespace KernelFilterGradVec
{
    constexpr uint32_t threads_per_block = 256;
    __device__ __constant__ uint16_t valid[8]{
        (1u << 0) | (1u << 1) | (1u << 8) | (1u << 10) | (1u << 12) | (1u << 14),
        (1u << 0) | (1u << 1) | (1u << 8) | (1u << 10) | (1u << 12) | (1u << 14),
        (1u << 2) | (1u << 3) | (1u << 9) | (1u << 11) | (1u << 13) | (1u << 15),
        (1u << 2) | (1u << 3) | (1u << 9) | (1u << 11) | (1u << 13) | (1u << 15),
        (1u << 0) | (1u << 1) | (1u << 8) | (1u << 10) | (1u << 12) | (1u << 14),
        (1u << 0) | (1u << 1) | (1u << 8) | (1u << 10) | (1u << 12) | (1u << 14),
        (1u << 2) | (1u << 3) | (1u << 9) | (1u << 11) | (1u << 13) | (1u << 15),
        (1u << 2) | (1u << 3) | (1u << 9) | (1u << 11) | (1u << 13) | (1u << 15),
    };
    __global__ __launch_bounds__(threads_per_block) void kernel(InputBuffer<uint64_t> seeds, OutputBuffer<SeedPos> outputs)
    {
        for (uint32_t seed_index = blockIdx.x; seed_index < seeds.len; seed_index += gridDim.x)
        {
            __shared__ ImprovedNoise shared_pn;
            for (uint32_t i = threadIdx.x; i < sizeof(ImprovedNoise) / sizeof(uint32_t); i += blockDim.x)
            {
                reinterpret_cast<uint32_t *>(&shared_pn)[i] = reinterpret_cast<const uint32_t *>(&KernelSeed1::results[seed_index].weirdness_0A)[i];
            }
            __syncthreads();
            const uint8_t *d = shared_pn.p;
            uint8_t y = (uint8_t)floorf(shared_pn.yo);
            int32_t base_wx = (int32_t)floorf(64.0f - shared_pn.xo * 128.0f);
            int32_t base_wz = (int32_t)floorf(64.0f - shared_pn.zo * 128.0f);
            for (uint32_t pos_index = threadIdx.x; pos_index < 65536; pos_index += blockDim.x)
            {
                uint8_t x = (uint8_t)(pos_index % 256);
                uint8_t z = (uint8_t)(pos_index / 256);
                uint32_t fail = 0;
                for (uint32_t i = 0; i < 8; i++)
                {
                    uint8_t dx = (i >> 0) & 1;
                    uint8_t dy = (i >> 1) & 1;
                    uint8_t dz = (i >> 2) & 1;
                    uint8_t gv = d[(uint8_t)(d[(uint8_t)(d[(uint8_t)(x + dx)] + y + dy)] + z + dz)] & 15;
                    fail += !(valid[i] & (1 << gv));
                    if (fail > 0)
                    {
                        break;
                    }
                }
                if (fail > 0)
                {
                    continue;
                }
                int32_t wx = base_wx + x * 128;
                int32_t wz = base_wz + z * 128;
                uint32_t result_index = atomicAdd(&outputs.len, 1);
                if (result_index < outputs.max_len)
                {
                    outputs.data[result_index] = {seed_index, wx, wz};
                }
            }
            __syncthreads();
        }
    }
    void run(InputBuffer<uint64_t> seeds, OutputBuffer<SeedPos> outputs)
    {
        kernel<<<2048, threads_per_block>>>(seeds, outputs);
        TRY_CUDA(cudaGetLastError());
    }
}

namespace KernelFilterOnlyA
{
    constexpr uint32_t threads_per_block = 256;
    constexpr uint32_t warps_per_block = threads_per_block / 32;
    __global__ __launch_bounds__(threads_per_block) void kernel(InputBuffer<SeedPos> inputs, OutputBuffer<SeedPos> outputs)
    {
        __shared__ GradDotTable shared_grad_dot_table;
        __shared__ KernelSeed1::ResultSampler<4> shared_octaves[warps_per_block];
        for (uint32_t i = threadIdx.x; i < sizeof(shared_grad_dot_table) / sizeof(uint32_t); i += blockDim.x)
        {
            reinterpret_cast<uint32_t *>(&shared_grad_dot_table)[i] = reinterpret_cast<const uint32_t *>(&device_grad_dot_table)[i];
        }
        __syncthreads();
        uint32_t lane_idx = threadIdx.x % 32;
        uint32_t warp_idx = threadIdx.x / 32;
        for (uint32_t input_index = blockIdx.x * warps_per_block + warp_idx; input_index < inputs.len; input_index += gridDim.x * warps_per_block)
        {
            const auto input = inputs.data[input_index];
            for (uint32_t i = lane_idx; i < sizeof(shared_octaves[0]) / sizeof(uint32_t); i += 32)
            {
                reinterpret_cast<uint32_t *>(&shared_octaves[warp_idx])[i] = reinterpret_cast<const uint32_t *>(&KernelSeed1::results[input.seed_index])[i];
            }
            __syncwarp();
            float thread_sum_wx = 0.0f;
            float thread_sum_wz = 0.0f;
            float thread_total_weight = 0.0f;
            for (uint32_t point_idx = lane_idx; point_idx < 1024; point_idx += 32)
            {
                int32_t px = input.x + ((int32_t)(point_idx % 32) - 16) * 4 + 2;
                int32_t pz = input.z + ((int32_t)(point_idx / 32) - 16) * 4 + 2;
                float value = 0.0f;
                value += sample_octave<chosen_weirdness_config.octaves_a[0]>(shared_grad_dot_table, shared_octaves[warp_idx].octaves[0], px, 0, pz);
                value += sample_octave<chosen_weirdness_config.octaves_a[1]>(shared_grad_dot_table, shared_octaves[warp_idx].octaves[2], px, 0, pz);
                float weight = value;
                thread_sum_wx += (float)px * weight;
                thread_sum_wz += (float)pz * weight;
                thread_total_weight += weight;
            }
            float total_sum_wx = warp_reduce_add<float>(thread_sum_wx);
            float total_sum_wz = warp_reduce_add<float>(thread_sum_wz);
            float total_weight = warp_reduce_add<float>(thread_total_weight);
            if (total_weight >= 725.0f && lane_idx == 0)
            {
                int32_t center_x = (int32_t)floorf(total_sum_wx / total_weight);
                int32_t center_z = (int32_t)floorf(total_sum_wz / total_weight);
                uint32_t result_index = atomicAdd(&outputs.len, 1);
                if (result_index < outputs.max_len)
                {
                    outputs.data[result_index] = {input.seed_index, center_x, center_z};
                }
            }
        }
    }
    void run(InputBuffer<SeedPos> inputs, OutputBuffer<SeedPos> outputs)
    {
        kernel<<<1024, threads_per_block>>>(inputs, outputs);
        TRY_CUDA(cudaGetLastError());
    }
}

namespace KernelFilterOnlyB
{
    constexpr uint32_t threads_per_block = 256;
    constexpr uint32_t warps_per_block = threads_per_block / 32;
    __global__ __launch_bounds__(threads_per_block) void kernel(InputBuffer<SeedPos> inputs, OutputBuffer<SeedPos> outputs)
    {
        __shared__ GradDotTable shared_grad_dot_table;
        __shared__ KernelSeed1::ResultSampler<4> shared_octaves;
        for (uint32_t i = threadIdx.x; i < sizeof(shared_grad_dot_table) / sizeof(uint32_t); i += blockDim.x)
        {
            reinterpret_cast<uint32_t *>(&shared_grad_dot_table)[i] = reinterpret_cast<const uint32_t *>(&device_grad_dot_table)[i];
        }
        __syncthreads();
        uint32_t lane_idx = threadIdx.x % 32;
        uint32_t warp_idx = threadIdx.x / 32;
        for (uint32_t input_index = blockIdx.x; input_index < inputs.len; input_index += gridDim.x)
        {
            const auto input = inputs.data[input_index];
            for (uint32_t i = threadIdx.x; i < sizeof(shared_octaves) / sizeof(uint32_t); i += blockDim.x)
            {
                reinterpret_cast<uint32_t *>(&shared_octaves)[i] = reinterpret_cast<const uint32_t *>(&KernelSeed1::results[input.seed_index])[i];
            }
            __syncthreads();
            for (uint32_t area_idx = warp_idx; area_idx < 108900; area_idx += warps_per_block)
            {
                int32_t ax = input.x + ((int32_t)(area_idx % 330) - 165) * 32768;
                int32_t az = input.z + ((int32_t)(area_idx / 330) - 165) * 32768;
                float value = 0.0f;
                for (uint32_t point_idx = lane_idx; point_idx < 64; point_idx += 32)
                {
                    int32_t px = ax + ((int32_t)(point_idx % 8) - 4) * 16 + 8;
                    int32_t pz = az + ((int32_t)(point_idx / 8) - 4) * 16 + 8;
                    value += sample_octave<chosen_weirdness_config.octaves_b[0]>(shared_grad_dot_table, shared_octaves.octaves[1], px, 0, pz);
                    value += sample_octave<chosen_weirdness_config.octaves_b[1]>(shared_grad_dot_table, shared_octaves.octaves[3], px, 0, pz);
                }
                float total = warp_reduce_add<float>(value);
                if (lane_idx == 0 && total >= 20.0f)
                {
                    uint32_t result_index = atomicAdd(&outputs.len, 1);
                    if (result_index < outputs.max_len)
                    {
                        outputs.data[result_index] = {input.seed_index, ax, az};
                    }
                }
            }
            __syncthreads();
        }
    }
    void run(InputBuffer<SeedPos> inputs, OutputBuffer<SeedPos> outputs)
    {
        kernel<<<4096, threads_per_block>>>(inputs, outputs);
        TRY_CUDA(cudaGetLastError());
    }
}

namespace KernelFilterAB
{
    constexpr uint32_t threads_per_block = 256;
    constexpr uint32_t warps_per_block = threads_per_block / 32;
    __global__ __launch_bounds__(threads_per_block) void kernel(InputBuffer<SeedPos> inputs, OutputBuffer<SeedPos> outputs)
    {
        __shared__ GradDotTable shared_grad_dot_table;
        __shared__ KernelSeed1::ResultSampler<4> shared_octaves[warps_per_block];
        for (uint32_t i = threadIdx.x; i < sizeof(shared_grad_dot_table) / sizeof(uint32_t); i += blockDim.x)
        {
            reinterpret_cast<uint32_t *>(&shared_grad_dot_table)[i] = reinterpret_cast<const uint32_t *>(&device_grad_dot_table)[i];
        }
        __syncthreads();
        uint32_t lane_idx = threadIdx.x % 32;
        uint32_t warp_idx = threadIdx.x / 32;
        for (uint32_t input_index = blockIdx.x * warps_per_block + warp_idx; input_index < inputs.len; input_index += gridDim.x * warps_per_block)
        {
            const auto input = inputs.data[input_index];
            for (uint32_t i = lane_idx; i < sizeof(shared_octaves[0]) / sizeof(uint32_t); i += 32)
            {
                reinterpret_cast<uint32_t *>(&shared_octaves[warp_idx])[i] = reinterpret_cast<const uint32_t *>(&KernelSeed1::results[input.seed_index])[i];
            }
            __syncwarp();
            float value = 0.0f;
            for (uint32_t point_idx = lane_idx; point_idx < 1024; point_idx += 32)
            {
                int32_t px = input.x + ((int32_t)(point_idx % 32) - 16) * 4 + 2;
                int32_t pz = input.z + ((int32_t)(point_idx / 32) - 16) * 4 + 2;
                value += sample_octave<chosen_weirdness_config.octaves_a[0]>(shared_grad_dot_table, shared_octaves[warp_idx].octaves[0], px, 0, pz);
                value += sample_octave<chosen_weirdness_config.octaves_a[1]>(shared_grad_dot_table, shared_octaves[warp_idx].octaves[2], px, 0, pz);
                value += sample_octave<chosen_weirdness_config.octaves_b[0]>(shared_grad_dot_table, shared_octaves[warp_idx].octaves[1], px, 0, pz);
                value += sample_octave<chosen_weirdness_config.octaves_b[1]>(shared_grad_dot_table, shared_octaves[warp_idx].octaves[3], px, 0, pz);
            }
            float total = warp_reduce_add<float>(value);
            if (lane_idx == 0 && total >= 1150.0f)
            {
                uint32_t result_index = atomicAdd(&outputs.len, 1);
                if (result_index < outputs.max_len)
                {
                    outputs.data[result_index] = {input.seed_index, input.x, input.z};
                }
            }
        }
    }
    void run(InputBuffer<SeedPos> inputs, OutputBuffer<SeedPos> outputs)
    {
        kernel<<<1024, threads_per_block>>>(inputs, outputs);
        TRY_CUDA(cudaGetLastError());
    }
}

constexpr bool is_pow2(uint32_t val)
{
    return (val & (val - 1)) == 0;
}

constexpr uint32_t log2(uint32_t val)
{
    return 31 - std::countl_zero(val);
}

struct CudaEventWrapper
{
    cudaEvent_t event;
    CudaEventWrapper() : event(nullptr) { TRY_CUDA(cudaEventCreate(&event)); }
    CudaEventWrapper(CudaEventWrapper &&other) : event(other.event) { other.event = nullptr; }
    ~CudaEventWrapper()
    {
        if (event == nullptr)
        {
            return;
        }
        TRY_CUDA(cudaEventDestroy(event));
    }
    void record(cudaStream_t stream = 0) const { TRY_CUDA(cudaEventRecord(event, stream)); }
    float elapsed(const CudaEventWrapper &end) const
    {
        float ms;
        TRY_CUDA(cudaEventElapsedTime(&ms, event, end.event));
        return ms;
    }
    void synchronize() const { TRY_CUDA(cudaEventSynchronize(event)); }
};

struct BufferLens
{
    uint32_t results_len_filter_yoffset;
    uint32_t results_len_filter_gradvec;
    uint32_t results_len_filter_3A;
    uint32_t results_len_filter_3B;
    uint32_t results_len_filter_island;
};

uint64_t random_start_seed()
{
    std::random_device device;
    return ((uint64_t)device() << 32) + (uint64_t)device();
}

GpuThread::GpuThread(int device, GpuOutputs &outputs) : Thread(), device(device), outputs(outputs)
{
    start();
}

void GpuThread::run()
{
    std::printf("Initializing device %d\n", device);
    TRY_CUDA(cudaSetDevice(device));
    init_grad_dot_table();
    BufferLens host_buffer_lens;
    BufferLens *device_buffer_lens;
    TRY_CUDA(cudaMalloc(&device_buffer_lens, sizeof(*device_buffer_lens)));
    uint64_t start_seed = random_start_seed();
    std::printf("Running device %d at %" PRId64 "\n", device, (int64_t)start_seed);
    DeviceBuffer buffer_seeds(sizeof(uint64_t) * KernelSeed1::threads_per_run);
    DeviceBuffer buffer_1(UINT32_C(1) << 30);
    DeviceBuffer buffer_2(UINT32_C(1) << 30);
    std::vector<SeedPos> h_buffer;
    namespace FilterGradVec = KernelFilterGradVec;
    namespace Filter3A = KernelFilterOnlyA;
    namespace Filter3B = KernelFilterOnlyB;
    namespace FilterIsland = KernelFilterAB;
    OutputBuffer<uint64_t> outputs_filter_yoffset(buffer_seeds, device_buffer_lens->results_len_filter_yoffset);
    uint32_t &host_outputs_filter_yoffset_len = host_buffer_lens.results_len_filter_yoffset;
    OutputBuffer<SeedPos> outputs_filter_gradvec(buffer_1, device_buffer_lens->results_len_filter_gradvec);
    uint32_t &host_outputs_filter_gradvec_len = host_buffer_lens.results_len_filter_gradvec;
    OutputBuffer<SeedPos> outputs_filter_3A(buffer_2, device_buffer_lens->results_len_filter_3A);
    uint32_t &host_outputs_filter_3A_len = host_buffer_lens.results_len_filter_3A;
    OutputBuffer<SeedPos> outputs_filter_3B(buffer_1, device_buffer_lens->results_len_filter_3B);
    uint32_t &host_outputs_filter_3B_len = host_buffer_lens.results_len_filter_3B;
    OutputBuffer<SeedPos> outputs_filter_island(buffer_2, device_buffer_lens->results_len_filter_island);
    uint32_t &host_outputs_filter_island_len = host_buffer_lens.results_len_filter_island;
    CudaEventWrapper event_start, event_yoffset, event_seed_1, event_filter_gradvec, event_filter_3A, event_filter_3B, event_filter_island;
    int print_interval = 4194304;
    double time_yoffset = 0.0;
    double time_seed_1 = 0.0;
    double time_filter_gradvec = 0.0;
    double time_filter_3A = 0.0;
    double time_filter_3B = 0.0;
    double time_filter_island = 0.0;
    uint64_t total_outputs_len_filter_yoffset = 0;
    uint64_t total_outputs_len_filter_gradvec = 0;
    uint64_t total_outputs_len_filter_3A = 0;
    uint64_t total_outputs_len_filter_3B = 0;
    uint64_t total_outputs_len_filter_island = 0;
    auto start = std::chrono::steady_clock::now();
    for (uint32_t i = 0; !should_stop(); i++)
    {
        TRY_CUDA(cudaMemsetAsync(device_buffer_lens, 0, sizeof(*device_buffer_lens)));
        event_start.record();
        KernelFilterYOffset::run(start_seed, outputs_filter_yoffset);
        start_seed += KernelFilterYOffset::threads_per_run;
        TRY_CUDA(cudaGetLastError());
        event_yoffset.record();
        KernelSeed1::kernel<<<KernelSeed1::threads_per_run / KernelSeed1::threads_per_block, KernelSeed1::threads_per_block>>>(outputs_filter_yoffset);
        event_seed_1.record();
        FilterGradVec::run(outputs_filter_yoffset, outputs_filter_gradvec);
        event_filter_gradvec.record();
        Filter3A::run(outputs_filter_gradvec, outputs_filter_3A);
        event_filter_3A.record();
        Filter3B::run(outputs_filter_3A, outputs_filter_3B);
        event_filter_3B.record();
        FilterIsland::run(outputs_filter_3B, outputs_filter_island);
        event_filter_island.record();
        TRY_CUDA(cudaMemcpyAsync(&host_buffer_lens, device_buffer_lens, sizeof(host_buffer_lens), cudaMemcpyDeviceToHost));
        event_filter_island.synchronize();
        time_yoffset += event_start.elapsed(event_yoffset) * 1e-3;
        time_seed_1 += event_yoffset.elapsed(event_seed_1) * 1e-3;
        time_filter_gradvec += event_seed_1.elapsed(event_filter_gradvec) * 1e-3;
        time_filter_3A += event_filter_gradvec.elapsed(event_filter_3A) * 1e-3;
        time_filter_3B += event_filter_3A.elapsed(event_filter_3B) * 1e-3;
        time_filter_island += event_filter_3B.elapsed(event_filter_island) * 1e-3;
        total_outputs_len_filter_yoffset += host_outputs_filter_yoffset_len;
        total_outputs_len_filter_gradvec += host_outputs_filter_gradvec_len;
        total_outputs_len_filter_3A += host_outputs_filter_3A_len;
        total_outputs_len_filter_3B += host_outputs_filter_3B_len;
        total_outputs_len_filter_island += host_outputs_filter_island_len;
        const auto &final_outputs = outputs_filter_island;
        const auto &final_outputs_len = host_outputs_filter_island_len;
        if (final_outputs_len > 0)
        {
            uint32_t len = final_outputs_len;
            h_buffer.resize(len);
            TRY_CUDA(cudaMemcpy(h_buffer.data(), final_outputs.data, sizeof(*h_buffer.data()) * len, cudaMemcpyDeviceToHost));
            {
                std::lock_guard lock(outputs.mutex);
                for (const auto &result : h_buffer)
                {
                    uint64_t seed;
                    TRY_CUDA(cudaMemcpy(&seed, &outputs_filter_yoffset.data[result.seed_index], sizeof(seed), cudaMemcpyDeviceToHost));
                    outputs.queue.push({seed, result.x * 4, result.z * 4});
                }
            }
        }
        if ((i + 1) % print_interval == 0)
        {
            auto end = std::chrono::steady_clock::now();
            double time_total = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count() * 1e-9;
            double kernel_time_total = time_yoffset + time_seed_1 + time_filter_gradvec + time_filter_3B + time_filter_3A + time_filter_island;
            size_t gpu_outputs_size;
            {
                std::lock_guard lock(outputs.mutex);
                gpu_outputs_size = outputs.queue.size();
            }
            std::printf("\n");
            std::printf("%16s%16s%16s%16s%16s%16s%16s%16s\n", "stage", "ms", "percent", "in", "out", "1 in", "sps", "gpu outputs");
            std::printf("\n");
            std::printf("%16s%16.3f%15.3f%%%16d%16" PRIu64 "%16.3f%15.3fG\n",
                        "crunch",
                        time_yoffset * 1e3,
                        time_yoffset / time_total * 100.0,
                        print_interval * KernelFilterYOffset::threads_per_run,
                        total_outputs_len_filter_yoffset,
                        (double)print_interval * KernelFilterYOffset::threads_per_run / total_outputs_len_filter_yoffset,
                        print_interval * KernelFilterYOffset::threads_per_run / time_yoffset * 1e-9);
            std::printf("%16s%16.3f%15.3f%%%16" PRIu64 "%16s%16s%15.3fM\n",
                        "seed",
                        time_seed_1 * 1e3,
                        time_seed_1 / time_total * 100.0,
                        total_outputs_len_filter_yoffset,
                        "-",
                        "-",
                        total_outputs_len_filter_yoffset / time_seed_1 * 1e-6);
            std::printf("%16s%16.3f%15.3f%%%16" PRIu64 "%16" PRIu64 "%16.3f%15.3fM\n",
                        "gradvec",
                        time_filter_gradvec * 1e3,
                        time_filter_gradvec / time_total * 100.0,
                        total_outputs_len_filter_yoffset,
                        total_outputs_len_filter_gradvec,
                        (double)total_outputs_len_filter_yoffset / total_outputs_len_filter_gradvec,
                        total_outputs_len_filter_yoffset / time_filter_gradvec * 1e-6);
            std::printf("%16s%16.3f%15.3f%%%16" PRIu64 "%16" PRIu64 "%16.3f%15.3fM\n",
                        "only_a",
                        time_filter_3A * 1e3,
                        time_filter_3A / time_total * 100.0,
                        total_outputs_len_filter_gradvec,
                        total_outputs_len_filter_3A,
                        (double)total_outputs_len_filter_gradvec / total_outputs_len_filter_3A,
                        total_outputs_len_filter_gradvec / time_filter_3A * 1e-6);
            std::printf("%16s%16.3f%15.3f%%%16" PRIu64 "%16" PRIu64 "%16.3f%15.3fM\n",
                        "only_b",
                        time_filter_3B * 1e3,
                        time_filter_3B / time_total * 100.0,
                        total_outputs_len_filter_3A,
                        total_outputs_len_filter_3B,
                        (double)total_outputs_len_filter_3A / total_outputs_len_filter_3B,
                        total_outputs_len_filter_3A / time_filter_3B * 1e-6);
            std::printf("%16s%16.3f%15.3f%%%16" PRIu64 "%16" PRIu64 "%16.3f%15.3fM\n",
                        "a_and_b",
                        time_filter_island * 1e3,
                        time_filter_island / time_total * 100.0,
                        total_outputs_len_filter_3B,
                        total_outputs_len_filter_island,
                        (double)total_outputs_len_filter_3B / total_outputs_len_filter_island,
                        total_outputs_len_filter_3B / time_filter_island * 1e-6);
            std::printf("%16s%16.3f%15.3f%%%16s%16s%16s%15.3fM%16zu\n",
                        "total",
                        time_total * 1e3,
                        kernel_time_total / time_total * 100.0,
                        "-",
                        "-",
                        "-",
                        print_interval * KernelFilterYOffset::threads_per_run / time_total * 1e-6,
                        gpu_outputs_size);
            std::printf("\n");
            start = end;
            time_yoffset = 0.0;
            time_seed_1 = 0.0;
            time_filter_gradvec = 0.0;
            time_filter_3B = 0.0;
            time_filter_3A = 0.0;
            time_filter_island = 0.0;
            total_outputs_len_filter_yoffset = 0;
            total_outputs_len_filter_gradvec = 0;
            total_outputs_len_filter_3B = 0;
            total_outputs_len_filter_3A = 0;
            total_outputs_len_filter_island = 0;
        }
    }
    TRY_CUDA(cudaFree(device_buffer_lens));
}
